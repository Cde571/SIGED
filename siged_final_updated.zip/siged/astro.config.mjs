import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// Astro configuration
// See https://docs.astro.build for more information on options and default values.

export default defineConfig({
  integrations: [
    tailwind({
      // Apply Tailwind just-in-time mode and include the Tailwind base styles.
      // When running `astro dev`, Tailwind styles will be injected into your pages automatically.
      config: {
        applyBaseStyles: true,
      },
    }),
  ],
  output: 'server',
  server: {
    host: true,
    port: 4321,
  },
});