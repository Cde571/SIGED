// server.js – Servidor backend de SIGED
//
// Este servidor Express mantiene la lógica de autenticación,
// registro de productos y operaciones CRUD básicas (crear,
// leer, actualizar y eliminar) usando un HashMap en memoria
// y persistiendo los datos en un archivo plano (`data/records.txt`).
//
// Para ejecutar:
//   npm install
//   node server.js

import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Configurar ruta del directorio actual (ya que __dirname no está disponible en ES modules)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Parsear application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// ======= Usuarios de prueba =========
// HashMap para usuarios de ejemplo (clave: nombre de usuario, valor: contraseña)
const usuarios = new Map([
  ['admin', '1234'],
  ['yuliana', '2025'],
  ['cristian', '4321'],
]);

// ======= Estructuras de datos para productos =========
// HashMap para productos (clave: ID, valor: objeto producto)
const productos = new Map();

// Ruta del archivo donde se guardan los productos
const DATA_PATH = path.join(__dirname, 'data', 'records.txt');

// Cargar productos existentes al iniciar el servidor
function cargarProductos() {
  if (!fs.existsSync(DATA_PATH)) return;
  const lines = fs.readFileSync(DATA_PATH, 'utf8').split('\n').filter(Boolean);
  for (const line of lines) {
    const [id, nombre, cantidadStr, precioStr] = line.split(',');
    productos.set(id, {
      id,
      nombre,
      cantidad: Number(cantidadStr),
      precio: Number(precioStr),
    });
  }
}

// Guardar todos los productos en el archivo (sobrescribe)
function guardarTodos() {
  const data = Array.from(productos.values())
    .map(p => `${p.id},${p.nombre},${p.cantidad},${p.precio}`)
    .join('\n');
  fs.writeFileSync(DATA_PATH, data);
}

// Guardar un producto individual al final del archivo
function guardarProducto(producto) {
  const line = `${producto.id},${producto.nombre},${producto.cantidad},${producto.precio}\n`;
  fs.appendFileSync(DATA_PATH, line);
}

// Inicializar productos al arrancar
cargarProductos();

// ======= Rutas del API =========

/**
 * POST /login
 * Autentica un usuario utilizando el HashMap `usuarios`.
 */
app.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (usuarios.has(username) && usuarios.get(username) === password) {
    res.send(`
      <html lang="es">
      <head><meta charset="UTF-8"><title>Bienvenido</title></head>
      <body style="font-family: sans-serif; margin: 2rem;">
        <h1>Bienvenido, ${username} ✅</h1>
        <p>Acceso concedido al sistema SIGED.</p>
        <p><a href="/lista">Ver lista de productos</a></p>
      </body></html>
    `);
  } else {
    res.send(`
      <html lang="es">
      <head><meta charset="UTF-8"><title>Error</title></head>
      <body style="font-family: sans-serif; margin: 2rem;">
        <h1>❌ Usuario o contraseña incorrectos</h1>
        <p><a href="/login">Volver al login</a></p>
      </body></html>
    `);
  }
});

/**
 * POST /productos
 * Crea un nuevo producto si su ID no existe.
 */
app.post('/productos', (req, res) => {
  const { id, nombre, cantidad, precio } = req.body || {};
  if (!id || !nombre || cantidad === undefined || precio === undefined) {
    return res.send('❌ Faltan datos del producto.');
  }
  if (productos.has(id)) {
    return res.send(`❌ Ya existe un producto con ID ${id}.`);
  }
  const prod = {
    id,
    nombre,
    cantidad: Number(cantidad),
    precio: Number(precio),
  };
  productos.set(id, prod);
  guardarProducto(prod);
  res.send(`✅ Producto ${id} registrado con éxito.`);
});

/**
 * POST /productos/consultar
 * Devuelve datos de un producto por ID.
 */
app.post('/productos/consultar', (req, res) => {
  const { id } = req.body || {};
  if (!id) return res.send('❌ Debe enviar un ID');
  if (productos.has(id)) {
    const p = productos.get(id);
    res.send(`
      <h3>Producto encontrado</h3>
      <ul>
        <li><b>ID:</b> ${p.id}</li>
        <li><b>Nombre:</b> ${p.nombre}</li>
        <li><b>Cantidad:</b> ${p.cantidad}</li>
        <li><b>Precio:</b> ${p.precio}</li>
      </ul>
    `);
  } else {
    res.send(`❌ No existe un producto con ID ${id}.`);
  }
});

/**
 * POST /productos/modificar
 * Modifica campos opcionales (nombre, cantidad, precio) de un producto existente.
 */
app.post('/productos/modificar', (req, res) => {
  const { id, nombre, cantidad, precio } = req.body || {};
  if (!id) return res.send('❌ Debe enviar el ID.');
  if (!productos.has(id)) {
    return res.send(`❌ Producto con ID ${id} no encontrado.`);
  }
  const prod = productos.get(id);
  if (nombre) prod.nombre = nombre;
  if (cantidad !== undefined && cantidad !== '') prod.cantidad = Number(cantidad);
  if (precio !== undefined && precio !== '') prod.precio = Number(precio);
  productos.set(id, prod);
  guardarTodos();
  res.send(`✅ Producto ${id} modificado con éxito.`);
});

/**
 * POST /productos/eliminar
 * Elimina un producto por su ID.
 */
app.post('/productos/eliminar', (req, res) => {
  const { id } = req.body || {};
  if (!id) return res.send('❌ Debe enviar el ID.');
  if (!productos.has(id)) {
    return res.send(`❌ Producto con ID ${id} no encontrado.`);
  }
  productos.delete(id);
  guardarTodos();
  res.send(`🗑️ Producto ${id} eliminado con éxito.`);
});

/**
 * GET /lista
 * Devuelve una tabla HTML con todos los productos registrados.
 */
app.get('/lista', (req, res) => {
  let rows = '';
  for (const p of productos.values()) {
    rows += `<tr><td>${p.id}</td><td>${p.nombre}</td><td>${p.cantidad}</td><td>${p.precio}</td></tr>`;
  }
  res.send(`
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <title>Lista de productos</title>
      <style>
        body { font-family: sans-serif; margin: 2rem; }
        table { border-collapse: collapse; width: 100%; max-width: 600px; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        th { background: #f3f4f6; }
        tr:nth-child(even) { background: #f9fafb; }
      </style>
    </head>
    <body>
      <h1>Lista de productos</h1>
      <table>
        <thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th><th>Precio</th></tr></thead>
        <tbody>
          ${rows || '<tr><td colspan="4">Sin productos</td></tr>'}
        </tbody>
      </table>
      <p><a href="http://localhost:4321">Volver al panel</a></p>
    </body>
    </html>
  `);
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor Express escuchando en http://localhost:${PORT}`);
});